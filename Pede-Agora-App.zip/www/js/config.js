var krms_config ={		
	'ApiUrl':"http://pedeagora.hospteste.ga/mobileapp/api",				
	'DialogDefaultTitle':"Notificação!",	
	'APIHasKey':"df54asd654f56sd4fa8d7fsad5f4s6d4f8sdf",
	'debug': false
};